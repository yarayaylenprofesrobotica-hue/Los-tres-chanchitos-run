LOS TRES CHANCHITOS - CARRERA A CASA

Archivos: index.html, style.css, game.js.

Para jugar: abrir index.html en un navegador.
Para publicar en GitHub Pages:
1. Crear un repositorio público en GitHub.
2. Subir los tres archivos a la raíz del repositorio (no solo el ZIP).
3. Ir a Settings > Pages > Build and deployment > Deploy from a branch.
4. Elegir main y /(root), luego Save.
5. Esperar la publicación y abrir la URL que GitHub muestre.

Controles: flechas izquierda/derecha y arriba o espacio para saltar. En celular, botones táctiles o deslizamientos.
Juego original de carreras de tres carriles inspirado en el género endless runner, sin recursos ni código de Subway Surfers.
